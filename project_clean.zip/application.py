﻿from flask import Flask
application = Flask(__name__)

@application.route('/')
def hello():
    return '<h1>Success! The App is Clean and Running</h1>'

if __name__ == "__main__":
    application.run(host='0.0.0.0', port=8000)
